from django.apps import AppConfig


class PwiproConfig(AppConfig):
    name = 'pwipro'
